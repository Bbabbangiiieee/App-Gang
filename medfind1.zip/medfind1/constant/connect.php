<?php 
// DB credentials.
$db1 = new mysqli ('localhost', 'root', '', 'login');
$db2 = new mysqli ('localhost', 'root', '', '18thavenuepharm');

?>





